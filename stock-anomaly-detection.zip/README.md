# 📈 Stock Market Anomaly Detection

## Overview
End-to-end Stock Market Anomaly Detection using Isolation Forest and Streamlit.

## How to Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Author
Nishank Mishra
